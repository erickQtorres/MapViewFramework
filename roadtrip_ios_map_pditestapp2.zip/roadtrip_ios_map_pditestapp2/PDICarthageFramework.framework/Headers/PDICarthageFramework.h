//
//  PDICarthageFramework.h
//  PDICarthageFramework
//
//  Created by Erick Quintanar on 2/20/18.
//  Copyright © 2018 Idean. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PDICarthageFramework.
FOUNDATION_EXPORT double PDICarthageFrameworkVersionNumber;

//! Project version string for PDICarthageFramework.
FOUNDATION_EXPORT const unsigned char PDICarthageFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PDICarthageFramework/PublicHeader.h>


